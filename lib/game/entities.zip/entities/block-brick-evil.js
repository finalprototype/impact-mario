ig.module(
	'game.entities.block-brick-evil'
)
.requires(
        'plugins.tween',
	'game.entities.block',
	'game.entities.brick-particle'
)
.defines(function(){

EntityBlockBrickEvil = EntityBlock.extend({
	
        init: function(x,y,settings){
            this.parent(x,y,settings);
		this.currentAnim = this.anims.brickgray;
        },
	
        update: function() {
                this.parent();
        },
	
	collideWith: function(entity,axis){
		this.parent(entity,axis);
		if(!this.active && axis=='y')
		{
			if(entity.pos.y>this.pos.y)
			{
				var up = this.tween( {pos: {y: this.orig.y-3}}, 0.08);
				var down = this.tween( {pos: {y: this.orig.y}}, 0.08,{onComplete:this.deactivate} );
				up.chain(down);
				up.start();
				entity.bumpSound.play();
			}
			else{
				entity.receiveDamage(1);
			}
		}
        },
	
	kill: function(){
		this.parent();
	},
});

});