ig.module(
	'game.entities.block-brick-red'
)
.requires(
        'plugins.tween',
	'game.entities.block',
	'game.entities.brick-particle',
	'game.entities.player'
)
.defines(function(){

EntityBlockBrickRed = EntityBlock.extend({
        
        
        init: function(x,y,settings){
		this.parent(x,y,settings);
		this.currentAnim = this.anims.brickred;
        },
	
        update: function() {
                this.parent();
        },
	
	collideWith: function(entity,axis){
		this.parent(entity,axis);
		if(!this.active && axis=='y' && (entity instanceof EntityPlayer))
		{
			if(entity.pos.y>this.pos.y)
			{
				var up = this.tween( {pos: {y: this.orig.y-3}}, 0.08);
				var down = this.tween( {pos: {y: this.orig.y}}, 0.08,{onComplete:this.deactivate} );
				up.chain(down);
				up.start();
				entity.bumpSound.play();
			}
		}
	}
});

});