/*
The EntityDebris will randomly spawn a certain count of EntityDebrisParticle 
entities for a certain duration.

The spawn position of the EntityDebrisParticle is inside the area occupied
by the EntityDebris entity. I.e. make the EntityDebris larger in Weltmeister
to increase the area in which particles will spawn.

Keys for Weltmeister:

duration
	Duration in seconds over which to spawn EntityDebrisParticle entities.
	Default: 5
	
count
	Total count of particles to spawn during the #duration# time span.
	Default: 5
*/

ig.module(
	'game.entities.brick-particle'
)
.requires(
	'impact.entity',
	'game.entities.particle'
)
.defines(function(){

EntityBrickParticle = ig.Entity.extend({
	_wmScalable: true,
	_wmDrawBox: true,
	_wmBoxColor: 'rgba(255, 170, 66, 0.7)',
	
	size: {x: 16, y: 16},
	count: 4,
	brickColor:0,
	lifetime: 8,
	
	
	init: function( x, y, settings ) {
		this.parent( x, y, settings );
		for(var i=0;i<3;i++)
		{
			var thisSettings = {frame:this.brickColor};
			ig.game.spawnEntity( BrickPiece, x, y,thisSettings );
		}
	},
	
	
	triggeredBy: function( entity, trigger ) {
		
	},
	
	
	update: function(){
		
	}
});



/*
The particles to spawn by the EntityDebris. See particle.js for more details.
*/

BrickPiece = EntityParticle.extend({
	vel: {x: 60, y: 20},
	frame:0,
	animSheet: new ig.AnimationSheet( 'media/bricks-particles.png', 8, 8 ),
		
	init: function( x, y, settings ) {		
		this.parent( x, y, settings );
		this.addAnim( 'idle', 5, [this.frame] );
	}
});

});