ig.module(
	'game.entities.powerup-flower'
)
.requires(
	'plugins.tween',
	'game.entities.powerup'
)
.defines(function(){

EntityPowerupFlower = EntityPowerup.extend({
	
	init: function( x, y, settings ) {
		this.parent( x, y, settings );
		this.currentAnim = this.anims.flower;
		this.collides = ig.Entity.COLLIDES.NEVER;
		var tween1 = this.tween( {pos: {y: this.pos.y-18}}, 1,{} );
		var tween2 = this.tween( {active: false}, 0,{} );
		tween1.chain(tween2);
		tween1.start();
	},
	
	ready: function(){
		this.parent();
	},
	
	update: function() {
		this.parent();
		if(!this.active){
			this.collides = ig.Entity.COLLIDES.LITE;
		}
	},
	
	deactivate: function(){
		this.parent();
	}
});


});