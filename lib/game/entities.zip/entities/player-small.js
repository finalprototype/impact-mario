ig.module(
	'game.entities.player-small'
)
.requires(
	'game.entities.player',
	'game.entities.powerup-mushroom'
)
.defines(function(){

EntityPlayerSmall = EntityPlayer.extend({
    
	update: function() {
		this.parent();
	}
});

});