ig.module(
	'game.entities.powerup-mushroom'
)
.requires(
	'plugins.tween',
	'game.entities.powerup',
	'game.entities.player'
)
.defines(function(){

EntityPowerupMushroom = EntityPowerup.extend({
	
	growSound: new ig.Sound('media/smb_powerup.ogg'),
	
	init: function( x, y, settings ) {
		this.parent( x, y, settings );
		this.currentAnim = this.anims.mushroom;
		this.collides = ig.Entity.COLLIDES.NEVER;
		var tween1 = this.tween( {pos: {y: this.pos.y-16}}, 1,{} );
		var tween2 = this.tween( {vel:{y:-100},active: false}, 0,{} );
		tween1.chain(tween2);
		tween1.start();
	},
	
	ready: function(){
		this.parent();
	},
	
	check: function(entity){
		this.parent(entity);
		if(this.active==false && (entity instanceof EntityPlayer))
		{
			this.kill();
			this.growSound.play();
			console.log('get bigger');
		}
	},
	
	update: function() {
		this.parent();
		if(!this.active && this.vel.x==0){
			this.collides = ig.Entity.COLLIDES.LITE;
			this.velocity = this.velocity==-60?60:-60;
			this.vel.x = this.velocity;
		}
	},
	
	deactivate: function(){
		this.parent();
	}
});


});