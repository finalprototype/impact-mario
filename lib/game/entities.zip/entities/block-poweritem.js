ig.module(
	'game.entities.block-poweritem'
)
.requires(
        'plugins.tween',
	'game.entities.block',
	'game.entities.powerup-mushroom',
	'game.entities.powerup-life',
	'game.entities.powerup-flower',
	'game.entities.powerup-star'
)
.defines(function(){

EntityBlockPoweritem = EntityBlock.extend({
        
        item:1,
        powerType:'grow',
        powerEntity:undefined,
        
        init: function(x,y,settings){
            this.parent(x,y,settings);
            this.currentAnim = this.anims.questionbrighton;
            switch(this.powerType)
            {
                case 'life':
                    this.powerEntity = EntityPowerupLife;
                    break;
                case 'grow':
                    this.powerEntity = (ig.game.player=='small') ? EntityPowerupMushroom : EntityPowerupFlower;
                    break;
                case 'star':
                    this.powerEntity = EntityPowerupStar;
                    break;
            }
        },
        
        update: function() {
                this.parent();
		
        },
	
	collideWith: function(entity,axis){
		this.parent(entity,axis);
		if(!this.active && axis=='y' && (entity instanceof EntityPlayer))
		{
			if(entity.pos.y>this.pos.y)
			{
				if(this.item>0)
				{
                                        console.log(this.powerType);
					var pm = ig.game.spawnEntity( this.powerEntity, this.pos.x, this.pos.y-4 );
                                        pm.zIndex = -10;
                                        ig.game.sortEntitiesDeferred();
					var up = this.tween( {pos: {y: this.orig.y-3}}, 0.08);
					var down = this.tween( {pos: {y: this.orig.y}}, 0.08,{onComplete:this.deactivate});
					up.chain(down);
					up.start();
					this.currentAnim = this.anims.questionbrightoff;
                                        this.item--;
				}else{
                                    entity.bumpSound.play();
				}
			}
		}
        },
});

});