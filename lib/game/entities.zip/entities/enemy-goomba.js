ig.module(
	'game.entities.enemy-goomba'
)
.requires(
	'game.entities.enemy'
)
.defines(function(){

EntityEnemyGoomba = EntityEnemy.extend({
	
	maxVel: {x: 40, y: 250},
	velocity:40,
        
	animSheet: new ig.AnimationSheet( 'media/enemy-goomba.png', 16, 16 ),
	stompSound: new ig.Sound('media/smb_stomp.ogg',true),
        
	init: function( x, y, settings ) {
		this.parent( x, y, settings );
		this.addAnim( 'walk', 0.1, [0,1] );
		this.addAnim( 'stomp', 1, [2] );
                this.currentAnim = this.anims.walk;
	},
        
        ready: function(){
            this.parent();
        },
        
        update: function() {
            if(this.health>0){
                this.parent();
                this.vel.x = this.velocity;
            }
		
        },
	
	collideWith: function(entity,axis){
		this.parent(entity,axis);
		if(this.active)
		{
                    if(entity instanceof EntityPlayer)
                    {
			if(ig.game.invincible)
			{
                            this.superKill();
			}else if(axis=='y' && entity.pos.y<this.pos.y)
			{
				this.currentAnim = this.anims.stomp;
				this.stompSound.play();
                                this.kill();
			} else {
                            entity.receiveDamage(1);
                        }
                    }else{
			if(axis=='x')
			{
                            //if(entity instanceof EntityEnemyGoomba)
                            //console.log('goomba hit')
                            this.velocity = this.velocity==-40?40:-40;
			}
                    }
		}
	},
	
	handleMovementTrace: function( res ) {
		this.parent(res);
	},
	
	kill: function(){
		this.parent();
	},
});

});