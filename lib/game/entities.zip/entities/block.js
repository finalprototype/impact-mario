ig.module(
	'game.entities.block'
)
.requires(
	'impact.entity'
)
.defines(function(){

EntityBlock = ig.Entity.extend({
	
	size: {x:16, y:16},
	offset: {x: 0, y: 0},
	maxVel: {x: 0, y: 0},
	friction: {x: 10000, y: 10000},
	orig:{x:-1,y:-1},
        gravityFactor:-5,
        flip:false,
	active:false,
        
        type: ig.Entity.TYPE.A,
        checkAgainst: ig.Entity.TYPE.BOTH,
	collides: ig.Entity.COLLIDES.FIXED,
	animSheet: new ig.AnimationSheet( 'media/blocks.png', 16, 16 ),
	
	init: function( x, y, settings ) {
		this.parent( x, y, settings );
		this.addAnim( 'brickred', 10, [0] );
		this.addAnim( 'brickblue', 10, [1] );
		this.addAnim( 'brickgray', 10, [2] );
		this.addAnim( 'questionbrighton', 0.12, [12,13,14,13,12,12] );
		this.addAnim( 'questiondarkon', 0.12, [15,16,17,16,15,15] );
		this.addAnim( 'questionbrightoff', 10, [6] );
		this.addAnim( 'questiondarkoff', 10, [7] );
		this.addAnim( 'unbreakablered', 10, [18] );
		this.addAnim( 'unbreakableblue', 10, [19] );
		this.addAnim( 'unbreakablegray', 10, [20] );
	},
	
	ready: function(){
		this.parent();
		this.orig.x = this.pos.x;
		this.orig.y = this.pos.y;
		this.active = false;
	},
        
        update: function() {
                this.parent();
        },
	
	handleMovementTrace: function( res ) {
		if( res.collision.y){
			console.log(res);
		}
		this.parent(res);
	},
        
        check: function(entity){
		this.parent(entity);
        },
	
	kill: function(){
		this.parent();
	},
	
	deactivate: function(){
		this.active = false;
	},
	
	activate: function(){
		this.active = true;
	},
});

});