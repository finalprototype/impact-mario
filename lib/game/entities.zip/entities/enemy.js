ig.module(
	'game.entities.enemy'
)
.requires(
	'impact.entity'
)
.defines(function(){

EntityEnemy = ig.Entity.extend({
	
	size: {x:16, y:16},
	offset: {x: 0, y: 0},
	maxVel: {x: 60, y: 200},
	friction: {x: 0, y: -30},
        jump:350,
	jumping : false,
	jumpcount : 0,
        gravityFactor:8,
	accelGround: 600,
	accelAir: 200,
        flip:false,
        active:true,
        
        type: ig.Entity.TYPE.B,
        checkAgainst: ig.Entity.TYPE.BOTH,
	collides: ig.Entity.COLLIDES.ACTIVE,
        health:1,
	
	init: function( x, y, settings ) {
		this.parent( x, y, settings );
	},
        
        update: function() {
            if(this.active && this.health>0){
                this.parent();
	    }   
		
        },
	
	handleMovementTrace: function( res ) {
		this.parent(res);
	},
	
	kill: function(){
		this.parent();
	},
	
	superKill: function(){
		this.kill();
	}
});

});