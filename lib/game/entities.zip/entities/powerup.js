ig.module(
	'game.entities.powerup'
)
.requires(
	'impact.entity'
)
.defines(function(){

EntityPowerup = ig.Entity.extend({
	size: {x: 16, y: 16},
	maxVel: {x: 60, y: 200},
	friction: {x: 0, y: -30},
	orig:{x:-1,y:-1},
        jump:200,
        gravityFactor:8,
	bounciness: 0,
	velocity:60,
        active:true,
	
	type: ig.Entity.TYPE.A,
	checkAgainst: ig.Entity.TYPE.A,
	collides: ig.Entity.COLLIDES.PASSIVE,
	animSheet: new ig.AnimationSheet( 'media/powerups.png', 16, 16 ),
	appearsSound: new ig.Sound('media/smb_powerup_appears.ogg',false),
	
	init: function( x, y, settings ) {
		this.parent( x, y, settings );
		this.addAnim( 'mushroom', 10, [8] );
		this.addAnim( 'life', 10, [9] );
		this.addAnim( 'flower', 0.1, [0,1,2,3,2,1] );
		this.addAnim( 'flowerdark', 0.1, [4,5,6,7,6,5] );
		this.addAnim( 'star', 0.05, [10,11,12,13] );
		this.appearsSound.play();
	},
	
	ready: function(){
                this.parent();
		this.orig.x = this.pos.x;
		this.orig.y = this.pos.y;
                this.activate();
	},
	
	update: function() {
		this.parent();
	},
	
	collideWith: function(entity,axis){
		this.parent(entity,axis);
	},
	
	check: function(entity) {
		this.parent(entity);
	},
	
	handleMovementTrace: function( res ) {
		this.parent(res);
	},
	
	deactivate: function(){
            console.log(this.pos);
		this.active = false;
	},
	
	activate: function(){
		this.active = true;
	},
});


});