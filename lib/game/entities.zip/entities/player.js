ig.module(
	'game.entities.player'
)
.requires(
	'impact.entity',
	'plugins.tween'
)
.defines(function(){

EntityPlayer = ig.Entity.extend({
	
	size: {x:10, y:15},
	offset: {x: 3, y: 1},
	maxVel: {x: 200, y: 200},
	friction: {x: 600, y: -30},
        jump:370,
	jumping : false,
	jumpcount : 0,
        gravityFactor:8,
	accelGround: 600,
	accelAir: 200,
	animationType:0,
        flip:false,
        
        type: ig.Entity.TYPE.A,
        checkAgainst: ig.Entity.TYPE.BOTH,
	collides: ig.Entity.COLLIDES.ACTIVE,
        health:1,
        
        
	bumpSound: new ig.Sound('media/smb_bump.ogg',true),
	dieSound: new ig.Sound('media/smb_playerdie.ogg',false),
	jumpSound: new ig.Sound('media/smb_jump_small.ogg',true),
	coinSound: new ig.Sound('media/smb_coin.ogg',true),
	animSheet: new ig.AnimationSheet( 'media/mario-small.png', 16, 16 ),
	
	init: function( x, y, settings ) {
		this.parent( x, y, settings );
		
		this.addAnim( 'idle0', 1, [0] );
		this.addAnim( 'walk0', 0.09, [1,2,3] );
		this.addAnim( 'run0', 0.05, [1,2,3] );
		this.addAnim( 'skid0', 1, [4] );
		this.addAnim( 'jump0', 1, [5] );
		this.addAnim( 'death', 1, [6] );
		
		this.addAnim( 'idle1', 0.13, [0,14,28,42] );
		this.addAnim( 'walk1', 0.09, [1,2,17,15,30,31,43,44,3,1,16,17,29,30,45] );
		this.addAnim( 'run1', 0.05, [1,2,3,15,16,17,29,30,31,43,44,45] );
		this.addAnim( 'skid1', 0.13, [4,18,32,46] );
		this.addAnim( 'jump1', 0.13, [5,19,33,47] );
		
		this.addAnim( 'idle2', 0.045, [0,14,28,42] );
		this.addAnim( 'walk2', 0.09, [1,16,31,43,2,17,29,44,3,15,30,45] );
		this.addAnim( 'run2', 0.05, [1,16,31,43,2,17,29,44,3,15,30,45] );
		this.addAnim( 'skid2', 0.045, [4,18,32,46] );
		this.addAnim( 'jump2', 0.045, [5,19,33,47] );
	},
	
	ready: function(){
		this.parent();
		ig.game.alive=true;
	},
        
        update: function() {
		
                this.parent();
            if(this.health>0){
		if( !this.standing ) {
			this.currentAnim = this.anims['jump'+this.animationType];
		}
		else if( this.vel.x != 0 ) {
                    if(ig.input.state('sprint'))
			this.currentAnim = this.anims['run'+this.animationType];
                    else
			this.currentAnim = this.anims['walk'+this.animationType];
                        
                    if((ig.input.state('right') && this.vel.x < 0) || (ig.input.state('left') && this.vel.x > 0)) {
			this.currentAnim = this.anims['skid'+this.animationType];
                    }
                    
		}
		else {
			this.currentAnim = this.anims['idle'+this.animationType];
		}
		
                this.maxVel.x = ig.input.state('sprint') ? 175 : 125;
		var accel = this.standing ? this.accelGround : this.accelAir;
		if( ig.input.state('left') ) {
			this.accel.x = ig.input.state('sprint') ? -accel : -accel/2;
			this.flip = true;
		}
		else if( ig.input.state('right') ) {
			this.accel.x = ig.input.state('sprint') ? accel : accel/2;
			this.flip = false;
		}
		else {
			this.accel.x = 0;
		}
		
		if(this.standing && this.jumpcount==0 && ig.input.pressed('jump'))
		{
			this.jumping=true;
			this.jumpSound.play();
		}
		if( this.jumping && ig.input.state('jump') ) {
			if(this.jumpcount<4){
				this.vel.y += -this.jump/4;
				this.jumpcount++;
			}
		}
		if(this.vel.y==0){
			this.jumping=false;
			this.jumpcount=0;
		}
		this.currentAnim.flip.x = this.flip;
		
		if(ig.game.invincible)
		{
			if( this.idleTimer.delta() > ig.game.invincibleLifetime ) {
				ig.game.invincible = false;
				this.animationType=0;
			}else if( this.idleTimer.delta() > ig.game.invincibleLifetime-5 ) {
				this.animationType=1;
			}
		}
	    }  else {
		
	    }
        },
	
	activateInvincibility: function(){
		this.idleTimer = new ig.Timer();
		ig.game.invincible = true;
		this.animationType=2;
	},
	
	handleMovementTrace: function( res ) {
		this.parent(res);
	},
	
	kill: function(){
		ig.game.alive=false;
		this.dieSound.play();
		this.currentAnim = this.anims.death;
		setTimeout(ig.game.respawn,4000);
		this.type = ig.Entity.TYPE.NONE;
		this.checkAgainst = ig.Entity.TYPE.NONE;
		this.collides = ig.Entity.COLLIDES.NEVER;
		var tween1 = this.tween( {pos: {y: this.pos.y-48}}, 0.5,{delay:0.5,easing:ig.Tween.Easing.Quadratic.EaseInOut} );
		var tween2 = this.tween( {pos: {y: ig.system.height+32}}, 1,{easing:ig.Tween.Easing.Quadratic.EaseInOut} );
		tween1.chain(tween2);
		tween1.start();
		//ig.game.removeEntity( this );
	},
});

});